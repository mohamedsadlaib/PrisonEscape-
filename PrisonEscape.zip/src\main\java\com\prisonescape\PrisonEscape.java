package com.prisonescape;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.data.type.WallSign;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.*;
import org.bukkit.util.Vector;

import java.util.*;

public class PrisonEscape extends JavaPlugin implements Listener, CommandExecutor {

    private static PrisonEscape instance;
    private HashMap<UUID, PlayerSession> players = new HashMap<>();
    private static final String[] STAGE_NAMES = {
            "الزنزانة", "الممر المظلم", "غرفة الحارس",
            "تسلق الجدار", "المتاهة", "غرفة الأسئلة",
            "السباق مع الوقت", "الزنزانة المائية", "الجسر المنهار",
            "غرفة السيوف", "التوازن", "الغرفة السرية",
            "لغز الكتل", "غرفة الحراس", "الحرية"
    };

    @Override
    public void onEnable() {
        instance = this;
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("escape").setExecutor(this);
        getLogger().info("PrisonEscape enabled!");
    }

    public static PrisonEscape getInstance() { return instance; }

    public class PlayerSession {
        UUID uuid;
        int currentStage;
        Location[] stageLocs;
        boolean active;
        boolean verified;
        int quizIndex;
        int zombieKills;

        PlayerSession(UUID uuid) {
            this.uuid = uuid;
            this.currentStage = 1;
            this.active = false;
            this.verified = false;
            this.stageLocs = new Location[16];
            this.quizIndex = 0;
            this.zombieKills = 0;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;

        if (args.length == 0) {
            p.sendMessage(ChatColor.GOLD + "=== هروب من السجن ===");
            p.sendMessage(ChatColor.YELLOW + "/escape join §f- ابدأ الهروب");
            p.sendMessage(ChatColor.YELLOW + "/escape stages §f- عرض المراحل");
            p.sendMessage(ChatColor.YELLOW + "/escape leave §f- خروج");
            p.sendMessage(ChatColor.YELLOW + "/escape admin §f- أوامر الإدارة");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "join" -> joinGame(p);
            case "leave" -> leaveGame(p);
            case "stages" -> showStages(p);
            case "admin" -> {
                if (!p.hasPermission("prisonescape.admin")) {
                    p.sendMessage(ChatColor.RED + "لا تملك صلاحية!");
                    return true;
                }
                handleAdmin(p, args);
            }
        }
        return true;
    }

    void joinGame(Player p) {
        if (players.containsKey(p.getUniqueId())) {
            PlayerSession existing = players.get(p.getUniqueId());
            if (existing.verified) {
                p.sendMessage(ChatColor.RED + "أنت بالفعل في اللعبة!");
                return;
            } else {
                // لم يتم التحقق بعد، نكمل
            }
        }
        PlayerSession session = new PlayerSession(p.getUniqueId());
        session.active = true;
        session.verified = false;
        players.put(p.getUniqueId(), session);

        p.getInventory().clear();
        p.setHealth(20);
        p.setFoodLevel(20);
        p.setGameMode(GameMode.ADVENTURE);

        Location spawn = p.getWorld().getSpawnLocation();
        p.teleport(spawn);
        p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "╔══════════════════════════╗");
        p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "║   !!! تحذير الأمن !!!     ║");
        p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "╠══════════════════════════╣");
        p.sendMessage(ChatColor.YELLOW + "║ اكتب كلمة المرور للتحقق    ║");
        p.sendMessage(ChatColor.YELLOW + "║     ↓↓↓↓↓↓↓↓↓↓↓              ║");
        p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "║     kahloch 3mk           ║");
        p.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "╚══════════════════════════╝");
    }

    void leaveGame(Player p) {
        PlayerSession s = players.remove(p.getUniqueId());
        if (s != null) {
            p.getInventory().clear();
            p.teleport(p.getWorld().getSpawnLocation());
            p.sendMessage(ChatColor.YELLOW + "غادرت اللعبة.");
        } else {
            p.sendMessage(ChatColor.RED + "لست في اللعبة!");
        }
    }

    void showStages(Player p) {
        p.sendMessage(ChatColor.GOLD + "=== مراحل الهروب ===");
        PlayerSession s = players.get(p.getUniqueId());
        int cur = s != null ? s.currentStage : 0;
        for (int i = 0; i < 15; i++) {
            String c = (i + 1 < cur) ? ChatColor.GREEN.toString() :
                       (i + 1 == cur) ? ChatColor.YELLOW.toString() : ChatColor.GRAY.toString();
            p.sendMessage(c + (i + 1) + ". " + STAGE_NAMES[i]);
        }
    }

    void handleAdmin(Player p, String[] args) {
        if (args.length < 2) {
            p.sendMessage(ChatColor.YELLOW + "/escape admin setspawn");
            p.sendMessage(ChatColor.YELLOW + "/escape admin setstage <1-15>");
            p.sendMessage(ChatColor.YELLOW + "/escape admin spawnmobs <stage>");
            return;
        }
        switch (args[1].toLowerCase()) {
            case "setspawn" -> {
                p.getWorld().setSpawnLocation(p.getLocation());
                p.sendMessage(ChatColor.GREEN + "تم تعيين نقطة البداية!");
            }
            case "setstage" -> {
                if (args.length < 3) { p.sendMessage(ChatColor.RED + "/escape admin setstage <1-15>"); return; }
                try {
                    int stage = Integer.parseInt(args[2]);
                    if (stage < 1 || stage > 15) { p.sendMessage(ChatColor.RED + "1-15 فقط"); return; }
                    PlayerSession s = players.computeIfAbsent(p.getUniqueId(), k -> new PlayerSession(p.getUniqueId()));
                    s.stageLocs[stage] = p.getLocation();
                    p.sendMessage(ChatColor.GREEN + "حفظ موقع المرحلة " + stage + ": " + STAGE_NAMES[stage - 1]);
                } catch (NumberFormatException e) {
                    p.sendMessage(ChatColor.RED + "رقم غير صالح");
                }
            }
            case "spawnmobs" -> {
                if (args.length < 3) { p.sendMessage(ChatColor.RED + "/escape admin spawnmobs <stage>"); return; }
                try {
                    int stage = Integer.parseInt(args[2]);
                    spawnStageMobs(p, stage);
                } catch (NumberFormatException e) {
                    p.sendMessage(ChatColor.RED + "رقم غير صالح");
                }
            }
        }
    }

    void spawnStageMobs(Player p, int stage) {
        Location loc = p.getLocation();
        switch (stage) {
            case 3 -> {
                Zombie guard = (Zombie) loc.getWorld().spawn(loc, Zombie.class);
                guard.setCustomName(ChatColor.RED + "حارس");
                guard.setCustomNameVisible(true);
                guard.setHealth(40);
                guard.getEquipment().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
                p.sendMessage(ChatColor.GREEN + "تم spawn حارس!");
            }
            case 10 -> {
                for (int i = 0; i < 5; i++) {
                    Zombie z = (Zombie) loc.getWorld().spawn(loc.clone().add(Math.random() * 10 - 5, 0, Math.random() * 10 - 5), Zombie.class);
                    z.setCustomName(ChatColor.RED + "زومبي");
                    z.setCustomNameVisible(true);
                }
                p.sendMessage(ChatColor.GREEN + "تم spawn 5 زومبي!");
            }
            case 14 -> {
                for (int i = 0; i < 5; i++) {
                    Zombie z = (Zombie) loc.getWorld().spawn(loc.clone().add(Math.random() * 15 - 7, 0, Math.random() * 15 - 7), Zombie.class);
                    z.setCustomName(ChatColor.RED + "حارس");
                    z.setCustomNameVisible(true);
                    z.setHealth(30);
                    z.getEquipment().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
                }
                p.sendMessage(ChatColor.GREEN + "تم spawn 5 حراس!");
            }
        }
    }

    void giveStageItems(Player p, int stage) {
        p.getInventory().clear();
        switch (stage) {
            case 1 -> {
                ItemStack key = new ItemStack(Material.TRIPWIRE_HOOK);
                ItemMeta m = key.getItemMeta();
                m.setDisplayName(ChatColor.WHITE + "مفتاح الزنزانة");
                m.setLore(Arrays.asList(ChatColor.GRAY + "استخدمه على الباب"));
                key.setItemMeta(m);
                p.getInventory().addItem(key);
            }
            case 3 -> p.getInventory().addItem(new ItemStack(Material.WOODEN_SWORD));
            case 4 -> {
                ItemStack boots = new ItemStack(Material.LEATHER_BOOTS);
                ItemMeta m = boots.getItemMeta();
                m.setDisplayName(ChatColor.WHITE + "حذاء القفز");
                m.addEnchant(Enchantment.FEATHER_FALLING, 4, true);
                boots.setItemMeta(m);
                p.getInventory().setBoots(boots);
            }
            case 10 -> {
                ItemStack sword = new ItemStack(Material.IRON_SWORD);
                ItemMeta sm = sword.getItemMeta();
                sm.setDisplayName(ChatColor.WHITE + "سيف حديدي");
                sm.addEnchant(Enchantment.SHARPNESS, 2, true);
                sword.setItemMeta(sm);
                p.getInventory().addItem(sword);
                p.getInventory().addItem(new ItemStack(Material.BOW));
                p.getInventory().addItem(new ItemStack(Material.ARROW, 32));
            }
            case 14 -> {
                ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
                ItemMeta sm = sword.getItemMeta();
                sm.setDisplayName(ChatColor.AQUA + "سيف الماس");
                sm.addEnchant(Enchantment.SHARPNESS, 3, true);
                sword.setItemMeta(sm);
                p.getInventory().addItem(sword);
                p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 3));
            }
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        PlayerSession s = players.get(p.getUniqueId());
        if (s == null || !s.active) return;

        Location loc = p.getLocation();

        // Stage 4: تسلق الجدار
        if (s.currentStage == 4 && loc.getY() >= 15 && s.stageLocs[4] != null && loc.distance(s.stageLocs[4]) < 10) {
            completeStage(p, s);
        }
        // Stage 5: المتاهة
        if (s.currentStage == 5 && s.stageLocs[5] != null && loc.distance(s.stageLocs[5]) < 2) {
            completeStage(p, s);
        }
        // Stage 8: الزنزانة المائية
        if (s.currentStage == 8 && s.stageLocs[8] != null && loc.distance(s.stageLocs[8]) < 2 && !p.isInWater()) {
            completeStage(p, s);
        }
        // Stage 9: الجسر المنهار
        if (s.currentStage == 9) {
            Block below = loc.clone().subtract(0, 1, 0).getBlock();
            if (below.getType() == Material.SAND) {
                new BukkitRunnable() {
                    public void run() {
                        below.setType(Material.AIR);
                        below.getWorld().playSound(below.getLocation(), Sound.BLOCK_SAND_BREAK, 1, 1);
                    }
                }.runTaskLater(this, 10);
            }
            if (s.stageLocs[9] != null && loc.distance(s.stageLocs[9]) < 2) {
                completeStage(p, s);
            }
        }
        // Stage 11: التوازن
        if (s.currentStage == 11) {
            if (s.stageLocs[11] != null && loc.distance(s.stageLocs[11]) < 2) {
                completeStage(p, s);
            }
        }
        // Stage 15: الحرية
        if (s.currentStage == 15 && s.stageLocs[15] != null && loc.distance(s.stageLocs[15]) < 3) {
            p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "✦✦✦ هنيئاً! أنت حر! ✦✦✦");
            p.getServer().broadcastMessage(ChatColor.GOLD + p.getName() + " هرب من السجن!");
            players.remove(p.getUniqueId());
            p.getInventory().clear();
            p.teleport(p.getWorld().getSpawnLocation());
            for (int i = 0; i < 20; i++) {
                p.getWorld().spawn(p.getLocation().add(Math.random()*2-1, 1, Math.random()*2-1), Firework.class);
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;
        Player p = e.getPlayer();
        PlayerSession s = players.get(p.getUniqueId());
        if (s == null || !s.active) return;

        Block b = e.getClickedBlock();

        // Stage 1: باب الزنزانة
        if (s.currentStage == 1 && b.getType() == Material.IRON_DOOR) {
            ItemStack item = p.getInventory().getItemInMainHand();
            if (item.getType() == Material.TRIPWIRE_HOOK && item.getItemMeta() != null
                    && item.getItemMeta().getDisplayName().contains("مفتاح")) {
                b.setType(Material.AIR);
                p.sendMessage(ChatColor.GREEN + "فتحت الزنزانة!");
                completeStage(p, s);
            } else {
                p.sendMessage(ChatColor.RED + "تحتاج مفتاح!");
            }
            e.setCancelled(true);
            return;
        }

        // Stage 2: الليزر
        if (s.currentStage == 2 && (b.getType() == Material.TRIPWIRE || b.getType() == Material.TRIPWIRE_HOOK)) {
            p.damage(6);
            p.sendMessage(ChatColor.RED + "✘ لمست ليزر!");
            e.setCancelled(true);
            return;
        }

        // Stage 6: غرفة الأسئلة
        if (s.currentStage == 6 && (b.getState() instanceof Sign)) {
            String[] qs = {
                    "ما عاصمة فرنسا؟|باريس|لندن|روما|برلين|1",
                    "كم عدد أيام الأسبوع؟|7|5|10|3|1",
                    "من اخترع المصباح؟|اديسون|نيوتن|اينشتاين|جاليليو|1",
                    "ما لون الدم؟|احمر|ازرق|اخضر|اصفر|1",
                    "ما اكبر كوكب؟|المشتري|زحل|المريخ|عطارد|1"
            };
            if (s.quizIndex >= qs.length) {
                p.sendMessage(ChatColor.GREEN + "✘ اجبت على كل الاسئلة!");
                completeStage(p, s);
                return;
            }
            String[] parts = qs[s.quizIndex].split("\\|");
            p.sendMessage(ChatColor.GOLD + "سؤال " + (s.quizIndex + 1) + ": " + parts[0]);
            p.sendMessage(ChatColor.YELLOW + "اكتب رقم الاجابة في الشات:");
            for (int i = 1; i <= 4; i++) {
                p.sendMessage(ChatColor.WHITE + i + ". " + parts[i]);
            }
            s.quizIndex++;
            e.setCancelled(true);
            return;
        }

        // Stage 7: بلاطة الضغط
        if (s.currentStage == 7 && b.getType() == Material.STONE_PRESSURE_PLATE) {
            p.sendMessage(ChatColor.GREEN + "✘ ضغطت على البلاطة!");
            completeStage(p, s);
            e.setCancelled(true);
            return;
        }

        // Stage 12: الزر السري
        if (s.currentStage == 12 && b.getType() == Material.STONE_BUTTON) {
            p.sendMessage(ChatColor.GREEN + "✘ لقيت الزر السري!");
            completeStage(p, s);
            e.setCancelled(true);
            return;
        }

        // Stage 13: لغز الكتل
        if (s.currentStage == 13 && b.getType() == Material.GOLD_BLOCK) {
            b.getWorld().getNearbyEntities(b.getLocation(), 10, 10, 10).forEach(e2 -> {
                if (e2 instanceof ItemFrame frame) frame.remove();
            });
            Location loc = b.getLocation();
            for (int x = -5; x <= 5; x++)
                for (int y = -5; y <= 5; y++)
                    for (int z = -5; z <= 5; z++) {
                        Block block = loc.clone().add(x, y, z).getBlock();
                        if (block.getType() == Material.GOLD_BLOCK) block.setType(Material.EMERALD_BLOCK);
                    }
            p.sendMessage(ChatColor.GREEN + "✘ حل اللغز! تحول الذهب إلى زمرد!");
            completeStage(p, s);
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        PlayerSession s = players.get(p.getUniqueId());
        if (s == null || !s.active) return;

        // التحقق من كلمة المرور
        if (!s.verified) {
            e.setCancelled(true);
            String msg = ChatColor.stripColor(e.getMessage().trim().toLowerCase());
            if (msg.equals("kahloch 3mk") || msg.equals("kahloch3mk")) {
                s.verified = true;
                Location spawn = s.stageLocs[1] != null ? s.stageLocs[1] : p.getWorld().getSpawnLocation();
                p.teleport(spawn);
                p.sendMessage(ChatColor.GREEN + "✔ تم التحقق! ابدأ الهروب!");
                p.sendMessage(ChatColor.GREEN + "☠ أكمل 15 مرحلة لتصل للحرية!");
                giveStageItems(p, 1);
            } else {
                p.sendMessage(ChatColor.RED + "✘ كلمة مرور خاطئة! اكتب: kahloch 3mk");
            }
            return;
        }

        if (s.currentStage != 6) return;
        e.setCancelled(true);
        String[] qs = {
                "ما عاصمة فرنسا؟|باريس|لندن|روما|برلين|1",
                "كم عدد أيام الأسبوع؟|7|5|10|3|1",
                "من اخترع المصباح؟|اديسون|نيوتن|اينشتاين|جاليليو|1",
                "ما لون الدم؟|احمر|ازرق|اخضر|اصفر|1",
                "ما اكبر كوكب؟|المشتري|زحل|المريخ|عطارد|1"
        };

        try {
            int answer = Integer.parseInt(e.getMessage().trim());
            if (answer < 1 || answer > 4) {
                p.sendMessage(ChatColor.RED + "اكتب رقم بين 1 و 4");
                return;
            }
            String[] parts = qs[s.quizIndex - 1].split("\\|");
            int correct = Integer.parseInt(parts[5]);
            if (answer == correct) {
                p.sendMessage(ChatColor.GREEN + "✓ إجابة صحيحة!");
                if (s.quizIndex >= qs.length) {
                    p.sendMessage(ChatColor.GREEN + "✘ اجبت على كل الاسئلة!");
                    completeStage(p, s);
                } else {
                    // next question
                    String[] next = qs[s.quizIndex].split("\\|");
                    p.sendMessage(ChatColor.GOLD + "سؤال " + (s.quizIndex + 1) + ": " + next[0]);
                    p.sendMessage(ChatColor.YELLOW + "اكتب رقم الاجابة:");
                    for (int i = 1; i <= 4; i++) {
                        p.sendMessage(ChatColor.WHITE + i + ". " + next[i]);
                    }
                    s.quizIndex++;
                }
            } else {
                p.sendMessage(ChatColor.RED + "✘ إجابة خاطئة!");
                p.damage(4);
            }
        } catch (NumberFormatException ex) {
            p.sendMessage(ChatColor.RED + "اكتب رقم 1-4 فقط");
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent e) {
        if (e.getEntity().getKiller() instanceof Player p) {
            PlayerSession s = players.get(p.getUniqueId());
            if (s == null || !s.active) return;

            // Stage 3: قتل الحارس
            if (s.currentStage == 3 && e.getEntity().getCustomName() != null
                    && e.getEntity().getCustomName().contains("حارس")) {
                p.sendMessage(ChatColor.GREEN + "✘ قتلت الحارس!");
                completeStage(p, s);
            }
            // Stage 10: قتل الزومبي
            if (s.currentStage == 10 && e.getEntity().getCustomName() != null
                    && e.getEntity().getCustomName().contains("زومبي")) {
                s.zombieKills++;
                if (s.zombieKills >= 5) {
                    p.sendMessage(ChatColor.GREEN + "✘ قتلت كل الزومبي!");
                    completeStage(p, s);
                }
            }
            // Stage 14: قتل الحراس
            if (s.currentStage == 14 && e.getEntity().getCustomName() != null
                    && e.getEntity().getCustomName().contains("حارس")) {
                boolean allDead = true;
                for (Entity ent : p.getWorld().getNearbyEntities(p.getLocation(), 25, 5, 25,
                        ent -> ent instanceof Zombie && ent.getCustomName() != null && ent.getCustomName().contains("حارس"))) {
                    if (!ent.isDead()) { allDead = false; break; }
                }
                if (allDead) {
                    p.sendMessage(ChatColor.GREEN + "✘ قتلت كل الحراس!");
                    completeStage(p, s);
                }
            }
        }
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            PlayerSession s = players.get(p.getUniqueId());
            if (s != null && s.currentStage == 11 && e.getCause() == EntityDamageEvent.DamageCause.FALL) {
                e.setCancelled(true);
                if (s.stageLocs[11] != null) p.teleport(s.stageLocs[11]);
                p.setHealth(20);
                p.sendMessage(ChatColor.RED + "✘ وقعت!");
            }
        }
    }

    void completeStage(Player p, PlayerSession s) {
        s.currentStage++;
        if (s.currentStage > 15) {
            p.sendMessage(ChatColor.GREEN + "أكملت جميع المراحل!");
            return;
        }
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        p.sendMessage(ChatColor.GREEN + "★ تقدمت إلى المرحلة " + s.currentStage + ": " + STAGE_NAMES[s.currentStage - 1] + "!");
        if (s.stageLocs[s.currentStage] != null) {
            p.teleport(s.stageLocs[s.currentStage]);
        }
        giveStageItems(p, s.currentStage);
    }

    @Override
    public void onDisable() {
        getLogger().info("PrisonEscape disabled");
    }
}
